// Runs in the page's MAIN world when the toolbar button is clicked.
// Reads the data captured by before.js and renders an "Additional Vehicle Details" panel.
(function () {
  const cap = globalThis.__bmwCapture;
  if (!cap) {
    alert('BMW MyGarage Trick: capture script not loaded. Make sure you are on https://mygarage.bmwusa.com and reload the page.');
    return;
  }

  let selected = null;
  try { selected = JSON.parse(window.sessionStorage.getItem('selected-vehicle') || 'null'); } catch (_) {}
  if (!selected || !selected.productionNumber) {
    alert('BMW MyGarage Trick: no vehicle selected. Click a vehicle in the top bar first.');
    return;
  }

  const prodNum = String(selected.productionNumber);

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderDetail(detail) {
    document.querySelectorAll('.c-custom-details').forEach(function (el) { el.remove(); });

    const status = escapeHtml(detail.orderStatusCode || 'N/A');
    const statusDesc = escapeHtml(detail.overHeadMessage || '');
    const statusDescLong = escapeHtml(detail.overHeadLongMessage || '');
    const vinShown = detail.vin && detail.vin !== 'NA' && detail.vin.length > 4
      ? escapeHtml(detail.vin)
      : 'No VIN assigned yet (status 150 required)';
    const prodDate = detail.prodDate && detail.prodDate.length > 4
      ? escapeHtml(detail.prodDate)
      : 'No production date assigned yet (status 150 required)';
    const retlDate = detail.retlDate && detail.retlDate.length > 4
      ? escapeHtml(detail.retlDate)
      : 'Not yet scheduled';
    const exterior = escapeHtml(detail.exteriorColor || '');
    const interior = escapeHtml(detail.interiorColor || '');
    const modelYear = escapeHtml(detail.modelYear || '');
    const naModel = escapeHtml(detail.naModelCode || '');

    const packages = Array.isArray(detail.packageDetails) ? detail.packageDetails : [];
    const packagesHtml = packages.map(function (pkg) {
      const opts = Array.isArray(pkg.options) ? pkg.options : [];
      const isAdded = /added/i.test(pkg.packageName || '');
      const items = opts.map(function (o) {
        return '<li style="margin:2px 0;">' + escapeHtml(typeof o === 'string' ? o : (o.name || JSON.stringify(o))) + '</li>';
      }).join('');
      return (
        '<details ' + (isAdded ? 'open' : '') + ' style="margin-top:12px;">' +
          '<summary style="cursor:pointer;font-weight:600;font-size:1rem;">' +
            escapeHtml(pkg.packageName || 'Options') + ' (' + opts.length + ')' +
          '</summary>' +
          '<ul style="margin:8px 0 0 0;padding-left:20px;list-style:disc;">' + items + '</ul>' +
        '</details>'
      );
    }).join('');

    const html =
      '<section class="c-custom-details" style="' +
        'margin:24px auto;max-width:960px;padding:24px 28px;' +
        'background:#f5f5f5;color:#262626;border-radius:8px;' +
        'font-family:inherit;line-height:1.5;">' +
        '<h2 style="margin:0 0 16px 0;font-size:1.4rem;letter-spacing:.02em;">Additional Vehicle Details</h2>' +
        '<p style="margin:6px 0;"><strong>Status Code:</strong> ' + status + '</p>' +
        '<p style="margin:6px 0;"><strong>Status:</strong> ' + statusDesc + (statusDescLong ? '<br><span style="color:#555;">' + statusDescLong + '</span>' : '') + '</p>' +
        '<p style="margin:6px 0;"><strong>VIN:</strong> ' + vinShown + '</p>' +
        '<p style="margin:6px 0;"><strong>Production Date:</strong> ' + prodDate + '</p>' +
        '<p style="margin:6px 0;"><strong>Retail Date:</strong> ' + retlDate + '</p>' +
        (modelYear || naModel ? '<p style="margin:6px 0;"><strong>Model:</strong> ' + modelYear + ' ' + naModel + '</p>' : '') +
        (exterior ? '<p style="margin:6px 0;"><strong>Exterior:</strong> ' + exterior + '</p>' : '') +
        (interior ? '<p style="margin:6px 0;"><strong>Interior:</strong> ' + interior + '</p>' : '') +
        (packagesHtml || '') +
      '</section>';

    const target = document.querySelector('.o-vehicle-details') || document.querySelector('.t-dashboard') || document.querySelector('main');
    if (target) target.insertAdjacentHTML('afterend', html);
    else document.body.insertAdjacentHTML('afterbegin', html);
  }

  const have = cap.byProdNum[prodNum];
  if (have && have.packageDetails) { renderDetail(have); return; }

  // No capture yet — try fetching directly using the auth headers we sniffed.
  if (!cap.headers || !(cap.headers.Authorization || cap.headers.authorization)) {
    alert('BMW MyGarage Trick: vehicle details not yet loaded. Click the vehicle tab in the top bar (or refresh the page) and try again.');
    return;
  }

  const headers = {};
  Object.keys(cap.headers).forEach(function (k) { headers[k] = cap.headers[k]; });
  if (!headers.Accept && !headers.accept) headers.Accept = 'application/json';

  const vinPart = selected.vin || 'null';
  const rel = selected.relationshipType || 'TRACK';
  const target = '/<brand-market>/profile/' + prodNum + '-' + vinPart + '/core';
  const url = '/bin/my-garage-services/forward'
    + '?target=' + encodeURIComponent(target)
    + '&brand=BMW'
    + '&gcid=' + encodeURIComponent(selected.gcid || '')
    + '&relationships=' + encodeURIComponent(rel)
    + '&market=US';

  fetch(url, { credentials: 'include', headers: headers })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (core) {
      if (!core || !Array.isArray(core.links)) throw new Error('no links');
      const trackLink = core.links.find(function (l) { return l.rel === rel; })
        || core.links.find(function (l) { return l.rel === 'FEATURES_AND_OPTIONS'; });
      if (!trackLink) throw new Error('no rel link');
      const path = trackLink.href.replace(/^https?:\/\/[^/]+/, '');
      const sep = path.indexOf('?');
      const proxied = '/bin/my-garage-services/forward'
        + '?target=' + encodeURIComponent(sep === -1 ? path : path.slice(0, sep))
        + (sep === -1 ? '' : '&' + path.slice(sep + 1))
        + '&brand=BMW';
      return fetch(proxied, { credentials: 'include', headers: headers }).then(function (r) { return r.ok ? r.json() : null; });
    })
    .then(function (data) {
      const detail = data && data.dataContent && data.dataContent.prodVehicleDetails && data.dataContent.prodVehicleDetails[0];
      if (!detail) {
        alert('BMW MyGarage Trick: could not fetch vehicle details.');
        return;
      }
      cap.byProdNum[prodNum] = Object.assign(cap.byProdNum[prodNum] || {}, detail);
      renderDetail(detail);
    })
    .catch(function (e) {
      alert('BMW MyGarage Trick: details not loaded yet. Click the vehicle tab in the top bar and try again.');
    });
})();
