chrome.action.onClicked.addListener(execScript);

async function execScript() {
  const tabId = await getTabId();
  if (tabId == null) return;
  chrome.scripting.executeScript({
    target: { tabId },
    files: ['execute.js'],
    world: 'MAIN'
  });
}

async function getTabId() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs.length > 0 ? tabs[0].id : null;
}
