# BMW MyGarage Chrome Trick

A Chrome extension that exposes the production status, options list, and other vehicle data that BMW's MyGarage dashboard hides behind its summary view.

## What it shows

When you click the toolbar icon on `mygarage.bmwusa.com`, an "Additional Vehicle Details" panel is rendered under the selected vehicle with:

- **Status Code** (e.g. 102, 150, 161, 200) and the matching status messages
- **VIN** (as soon as BMW assigns one — typically at status 150)
- **Production Date** and **Retail Date**
- **Model**, **Exterior**, and **Interior** color
- **Added options** (the package you configured)
- **Standard Features** (the full ~50-item list)

The data is sourced from BMW's own internal API — the extension passively observes the responses BMW's frontend already fetches.

## Install

1. Download / clone this folder so you have a local copy.
2. Open `chrome://extensions/` in Chrome.
3. Toggle **Developer mode** on (top-right corner).
4. Click **Load unpacked** and select this `mygarage` folder.
5. Pin the extension icon to your toolbar (puzzle-piece menu → pin).

## Use

1. Go to <https://mygarage.bmwusa.com/dashboard.html> and sign in.
2. Click a vehicle in the top thumbnail bar.
3. Click the extension's toolbar icon.

The details panel appears under the vehicle card. Click the icon again to refresh, or click a different vehicle and click the icon again to see that one.

If you click the icon before BMW's frontend has finished loading the data, the extension will fetch it itself using the auth headers it already sniffed.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest. Restricts the extension to `mygarage.bmwusa.com` only. |
| `before.js` | Runs at `document_start` in the page's main world. Hooks `fetch` and `XMLHttpRequest` so any response containing `dataContent.prodVehicleDetails[0]` is indexed by production number. |
| `execute.js` | Runs when the toolbar icon is clicked. Reads the selected vehicle from `sessionStorage`, looks up the captured detail, and injects the panel. |
| `background.js` | Service worker. Listens for the toolbar click and runs `execute.js` in the page's main world. |

## Updating after code changes

Edit a file, then go back to `chrome://extensions/` and click the circular reload arrow on the extension's tile. Reload the BMW tab afterwards so the new `before.js` runs.

## Permissions

- `host_permissions: https://mygarage.bmwusa.com/*` — only this domain.
- `scripting` — to inject `execute.js` on click.
- `activeTab` — to target the active tab.

No data leaves your browser; the extension only reads what BMW's own page already has.

## Compatibility

- Chrome / Edge / Brave / Opera (any Chromium browser, version 102+).
- Manifest V3.
