// Runs at document_start in the page's MAIN world.
// Hooks fetch + XHR so any response containing dataContent.prodVehicleDetails
// gets indexed by prodNum for execute.js to render later.
(function () {
  if (globalThis.__bmwCaptureInstalled) return;
  globalThis.__bmwCaptureInstalled = true;

  const cap = globalThis.__bmwCapture = {
    byProdNum: Object.create(null),
    headers: null
  };

  function ingest(text) {
    if (!text || typeof text !== 'string') return;
    if (text[0] !== '{' && text[0] !== '[') return;
    let json;
    try { json = JSON.parse(text); } catch (_) { return; }
    const detail = json && json.dataContent && Array.isArray(json.dataContent.prodVehicleDetails)
      ? json.dataContent.prodVehicleDetails[0]
      : null;
    if (!detail || !detail.prodNum) return;
    const existing = cap.byProdNum[detail.prodNum] || {};
    cap.byProdNum[detail.prodNum] = Object.assign(existing, detail);
  }

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      const p = origFetch.apply(this, arguments);
      p.then(function (res) {
        if (!res || !res.ok) return;
        const ct = res.headers && res.headers.get && res.headers.get('content-type');
        if (ct && ct.indexOf('json') === -1) return;
        try { res.clone().text().then(ingest).catch(function () {}); } catch (_) {}
      }).catch(function () {});
      return p;
    };
  }

  const XHR = window.XMLHttpRequest;
  if (XHR && XHR.prototype) {
    const origOpen = XHR.prototype.open;
    const origSend = XHR.prototype.send;
    const origSetH = XHR.prototype.setRequestHeader;

    XHR.prototype.open = function (method, url) {
      this.__bmwUrl = url;
      this.__bmwHeaders = {};
      return origOpen.apply(this, arguments);
    };

    XHR.prototype.setRequestHeader = function (k, v) {
      if (this.__bmwHeaders) this.__bmwHeaders[k] = v;
      return origSetH.apply(this, arguments);
    };

    XHR.prototype.send = function () {
      const xhr = this;
      xhr.addEventListener('load', function () {
        if (xhr.status < 200 || xhr.status >= 300) return;
        if (xhr.__bmwHeaders && (xhr.__bmwHeaders.Authorization || xhr.__bmwHeaders.authorization)) {
          cap.headers = xhr.__bmwHeaders;
        }
        try { ingest(xhr.responseText); } catch (_) {}
      });
      return origSend.apply(this, arguments);
    };
  }
})();
